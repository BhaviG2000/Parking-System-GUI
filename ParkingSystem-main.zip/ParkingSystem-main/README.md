# ParkingSystem
A client parking booking system built in Java

Contains an intricate system that impliments the Singleton, Facade, Factory, Template, and Iterable Design Pattern.

Under the test package, there are some preliminary JUNIT files to test program functiionality.
