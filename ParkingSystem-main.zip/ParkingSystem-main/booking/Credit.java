package booking;

public class Credit extends Method {

	public Credit(int cardNum, int ccv, String firstName, String lastName, int expiry, String address) {
		super(cardNum, ccv, firstName, lastName, expiry, address);
	}

}
