package booking;

public class Debit extends Method {

	public Debit(int cardNum, int ccv, String firstName, String lastName, int expiry, String address) {
		super(cardNum, ccv, firstName, lastName, expiry, address);
	}

}
