package booking;

public class Mobile extends Method {

	public Mobile(int cardNum, int ccv, String firstName, String lastName, int expiry, String address) {
		super(cardNum, ccv, firstName, lastName, expiry, address);
	}

}
