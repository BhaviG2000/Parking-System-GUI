package client;

public class Faculty extends Client {

	public Faculty(String newEmail, String newPass) {
		super(newEmail, newPass,8);
	}

}
