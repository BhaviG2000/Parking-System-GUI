package client;

public class NonFaculty extends Client {

	public NonFaculty(String newEmail, String newPass) {
		super(newEmail, newPass,10);
	}

}
