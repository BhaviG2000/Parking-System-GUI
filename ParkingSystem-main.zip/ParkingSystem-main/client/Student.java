package client;

public class Student extends Client {

	public Student(String newEmail, String newPass) {
		super(newEmail, newPass, 5);
	}

}
