package tests;

import lots.*;
import client.*;
import manager.*;
import booking.*;

public class main {

	public static void main(String[] args) {
		
		//demo code
	}

}
